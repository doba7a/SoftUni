﻿namespace Logger.Enums
{
    public enum ErrorLevel
    {
        INFO, WARNING, ERROR, CRITICAL, FATAL
    }
}
