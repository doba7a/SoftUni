﻿public interface IClinic
{
    string Name { get; }

    Room[] Rooms { get; }
}

