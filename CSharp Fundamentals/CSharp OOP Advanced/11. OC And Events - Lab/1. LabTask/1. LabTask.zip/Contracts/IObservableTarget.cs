﻿public interface IObservableTarget : ITarget, IObserver
{
}
