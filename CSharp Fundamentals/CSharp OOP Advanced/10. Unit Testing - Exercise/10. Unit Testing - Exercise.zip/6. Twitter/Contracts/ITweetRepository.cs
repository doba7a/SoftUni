﻿public interface ITweetRepository
{
    void SaveTweet(string content);
}
