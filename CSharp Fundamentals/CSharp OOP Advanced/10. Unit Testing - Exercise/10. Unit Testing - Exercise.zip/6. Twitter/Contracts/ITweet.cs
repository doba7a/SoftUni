﻿public interface ITweet
{
    void ReceiveMessage(string message);
}