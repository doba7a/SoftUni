﻿public interface IMath
{
    int Abs(double a, double b);

    int Floor(double a);
}
