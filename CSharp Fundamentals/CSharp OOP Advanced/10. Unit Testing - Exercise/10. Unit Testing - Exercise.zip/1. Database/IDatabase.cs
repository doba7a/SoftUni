﻿public interface IDatabase
{
    void Add(int value);

    void Remove();

    int[] Fetch();
}

