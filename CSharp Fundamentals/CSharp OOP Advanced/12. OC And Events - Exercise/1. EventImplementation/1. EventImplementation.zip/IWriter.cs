﻿public interface IWriter
{
    void WriteLine(string line);
}
