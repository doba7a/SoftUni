﻿public interface IIdentifiable
{
    string Name { get; }
}

