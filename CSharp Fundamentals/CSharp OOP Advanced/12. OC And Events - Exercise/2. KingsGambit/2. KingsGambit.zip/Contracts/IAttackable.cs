﻿public interface IAttackable
{
    void RespondToAttack();
}

