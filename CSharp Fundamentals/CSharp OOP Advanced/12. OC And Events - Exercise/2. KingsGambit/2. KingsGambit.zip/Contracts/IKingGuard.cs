﻿public interface IKingGuard : IIdentifiable, IKillable
{
}

