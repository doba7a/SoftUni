﻿using System.Collections.Generic;

public class EmployeeRepository : List<IEmployee>
{
}

