﻿public interface IUnit : IDestroyable, IAttacker
{

}

