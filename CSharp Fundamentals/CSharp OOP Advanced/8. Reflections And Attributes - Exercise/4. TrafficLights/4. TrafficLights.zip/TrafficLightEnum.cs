﻿public enum TrafficLightEnum
{
    Red = 0,
    Green = 1,
    Yellow = 2
}

