﻿public enum Clarity
{
    Chipped = 1,
    Regular = 2,
    Perfect = 5,
    Flawless = 10
}

