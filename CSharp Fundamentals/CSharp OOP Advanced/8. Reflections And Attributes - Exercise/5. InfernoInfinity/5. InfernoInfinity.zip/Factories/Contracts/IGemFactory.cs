﻿public interface IGemFactory
{
    IGem CreateGem(Clarity gemClarity, string kindOfGem);
}

