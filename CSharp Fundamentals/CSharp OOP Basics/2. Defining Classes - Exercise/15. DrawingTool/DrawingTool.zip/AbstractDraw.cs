﻿public abstract class AbstractDraw
{
    public abstract void Draw();
}