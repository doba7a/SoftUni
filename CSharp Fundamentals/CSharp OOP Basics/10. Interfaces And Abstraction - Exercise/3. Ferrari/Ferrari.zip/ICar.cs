﻿public interface ICar
{
    string Brake();

    string Gas();
}


