﻿public interface ICallable
{
    bool ValidNumber(string number);

    string CallingNumber(string number);
}


