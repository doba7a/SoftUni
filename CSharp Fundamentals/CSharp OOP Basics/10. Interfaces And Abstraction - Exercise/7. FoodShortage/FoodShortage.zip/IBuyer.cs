﻿public interface IBuyer
{
    int Food { get; set; }

    string Name { get; }

    void BuyFood();
}

