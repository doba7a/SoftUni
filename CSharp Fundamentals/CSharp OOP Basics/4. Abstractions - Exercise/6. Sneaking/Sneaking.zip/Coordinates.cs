﻿public class Coordinates
{
    public int Row { get; set; }
    public int Column { get; set; }
}
