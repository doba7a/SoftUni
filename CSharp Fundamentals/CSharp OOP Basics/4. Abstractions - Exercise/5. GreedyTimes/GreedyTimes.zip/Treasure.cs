﻿public class Treasure
{
    public string Name { get; set; }
    public long Amount { get; set; }
}
